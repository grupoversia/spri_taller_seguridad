#/bin/bash
cat COR-003_simulacion_evento_nmap.txt >> /var/log/logstash/osquery_20170905.out
sleep 10s
cat COR-003_simulacion_evento_WIN-001.txt >> /etc/sec/logs/SEC_alerts.log
