#/bin/bash
cat /home/pocaud1/Alvaro/sec-2.7.11/logs/test >> /var/log/logstash/Suricata_2017-08-17.out
cat /home/pocaud1/Alvaro/sec-2.7.11/logs/test2 >> /var/log/osquery/osqueryd.results.log
