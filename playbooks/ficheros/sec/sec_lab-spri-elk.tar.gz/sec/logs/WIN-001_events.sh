#!/bin/bash
if [ $# -eq 0 ]
then
  echo "$0 : usuario dominio contraseña ip"
else
  if [ $# -eq 4 ]
  then
    for ((i=1;i<=20;i++)); 
    do 
      /usr/bin/xfreerdp /u:$1 /d:$2 /p:$3 /v:$4
    done
  else
    echo "$0 : usuario dominio contraseña ip"
    echo "Es necesario pasar los 4 parametros"
  fi
fi
