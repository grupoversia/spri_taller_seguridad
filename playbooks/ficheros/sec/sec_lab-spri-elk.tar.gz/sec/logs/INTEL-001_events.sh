#/bin/bash
cat /etc/sec/logs/T2.txt >> /var/log/logstash/osquery_20170905.out 
