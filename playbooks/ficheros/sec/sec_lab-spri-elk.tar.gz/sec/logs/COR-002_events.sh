#/bin/bash
cat /etc/sec/logs/COR-002_login_fallido_event.txt >> /var/log/logstash/osquery_20170905.out
sleep 10s
cat  /etc/sec/logs/COR-002_2_login_fallido_event.txt  >> /var/log/logstash/osquery_20170905.out
sleep 10s
cat  /etc/sec/logs/COR-002_2_login_fallido_event.txt  >> /var/log/logstash/osquery_20170905.out
sleep 10s
cat /etc/sec/logs/COR-002_login_correcto_event.txt >> /var/log/logstash/osquery_20170905.out
