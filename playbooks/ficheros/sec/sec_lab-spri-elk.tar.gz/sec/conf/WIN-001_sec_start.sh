/etc/sec/sec --blocksize=1024 --bufsize=10 --cleantime=1 --nofromstart --nointcontexts --intevents --nokeepopen --detach  --input=/var/log/logstash/osquery_201709*.out --conf=/etc/sec/conf/WIN-001.conf  --log=/etc/sec/logs/WIN-001_alert.log --debug=6

