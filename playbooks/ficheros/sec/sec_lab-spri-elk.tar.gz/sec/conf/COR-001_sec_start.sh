#/bin/bash
/home/pocaud1/Alvaro/sec-2.7.11/sec --blocksize=1024 --bufsize=10 --cleantime=1 --nofromstart --nointcontexts --intevents --nokeepopen --detach --input=/var/log/logstash/Suricata_2017-08-17.out --input=/var/log/osquery/osqueryd.results.log --conf=/home/pocaud1/Alvaro/sec-2.7.11/conf/COR-001.conf --log=/home/pocaud1/Alvaro/sec-2.7.11/logs/COR-001_alert.log --debug=6
