#/bin/bash
/home/versia/Desktop/sec-2.7.11/sec --blocksize=1024 --bufsize=10 --cleantime=1 --nofromstart --nointcontexts --intevents --nokeepopen --input=/home/versia/Desktop/sec-2.7.11/logs/monitor.me --conf=/home/versia/Desktop/sec-2.7.11/conf/AV-003.conf --log=/home/versia/Desktop/sec-2.7.11/debug/AV-003.log --debug=6
