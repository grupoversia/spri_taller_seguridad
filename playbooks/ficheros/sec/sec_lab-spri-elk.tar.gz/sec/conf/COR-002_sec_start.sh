/etc/sec/sec --blocksize=1024 --bufsize=10 --cleantime=1 --nofromstart --nointcontexts --intevents --nokeepopen --detach  --input=/var/log/logstash/linux_auth_201709*.out --input=/var/log/logstash/osquery_201709*.out --conf=/etc/sec/conf/COR-002.conf  --log=/etc/sec/logs/COR-002_alert.log --debug=6

